--
menorMaior :: Int -> Int -> Int -> (Int, Int)
menorMaior a b c = ((maior a (maior b c)) , (menor a (menor b c)))

maior :: Int -> Int -> Int
maior m n
 | m > n = m
 | otherwise = n

menor :: Int -> Int -> Int
menor m n
 | m > n = n
 | otherwise = m


--
ordenaTripla :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla (a, b, c)
 | menorMaior a b c == (a,c) = (c, b, a)
 | menorMaior a b c == (a,b) = (b, c, a)
 | menorMaior a b c == (b,a) = (a, c, b)
 | menorMaior a b c == (b,c) = (c, a, b)
 | menorMaior a b c == (c,a) = (a, b, c)
 | menorMaior a b c == (c,b) = (b, a, c)


--
type Ponto = (Float, Float)
type Reta = (Ponto, Ponto)

fstPoint :: Ponto -> Float
fstPoint (x, y) = x

scdPoint :: Ponto -> Float
scdPoint (x,y) = y

vertical :: Reta -> Bool
vertical (p1, p2)
 | (fst p1) == (fst p2) = True
 | otherwise = False


--
pontoY :: Float -> Reta -> Float
pontoY x (p1, p2) = (((x-(fst p1)) * ((snd p2) - (snd p1))) / ((fst p2) - (fst p1))) + (snd p1) -- ((x-x1)*(y2-y1))/(x2-x1) + y1

-- se for uma reta vertical, o resultado dá infinito


--quicksort
qs :: [Int] -> [Int]
qs [] = []
qs (a:as) = (qs [x|x<-as, x<=a]) ++ (a:qs[y|y<-as, y > a])


--member
member :: [Int] -> Int -> Bool
member lista a  = [x|x <- lista, (x==a)] /= []

-- biblioteca
type Pessoa = String
type Livro = String
type BancoDados = [(Pessoa, Livro)]


--jeito1
livros :: BancoDados -> Pessoa -> [Livro]
livros bd p 
 | bd == [] = []
 | otherwise = [snd x|x <- bd, (fst x==p)]

--jeito2
livros2 :: BancoDados -> Pessoa -> [Livro]
livros2 [] p = []
livros2 bd p = [snd x|x <- bd, (fst x==p)]


emprestimos :: BancoDados -> Livro -> [Pessoa]
emprestimos [] l = []
emprestimos bd l = [fst x|x <- bd, (snd x==l)]


emprestado :: BancoDados -> Livro -> Bool
emprestado [] l = False
emprestado ((p,l):t) livro         -- ou bd livro
 | l == livro = True               -- (snd (head bd) == livro) = True   
 | otherwise = emprestado t livro  -- otherwise = emprestado (tail lista) livro


qtdEmprestimos :: BancoDados -> Pessoa -> Int
qtdEmprestimos [] p = 0
qtdEmprestimos bd p
 | fst (head bd) == p = 1 + qtdEmprestimos (tail bd) p
 | otherwise = qtdEmprestimos (tail bd) p


emprestar :: BancoDados -> Pessoa -> Livro -> BancoDados
emprestar [] p l = [(p,l)]
emprestar bd p l
 | ([snd x|x <- bd, (snd x == l)]) == [] = (head bd):(tail bd ++ [(p,l)])
 | otherwise = bd

 
devolver :: BancoDados -> Pessoa -> Livro -> BancoDados
devolver bd p l = [x| x <- bd, (x /= (p,l))]